import os
import re
import sys
import json

import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import xbmcvfs

import requests
import six

from six.moves import urllib_parse
from six.moves.urllib.parse import quote_plus, parse_qsl
from bs4 import BeautifulSoup

translatePath = xbmc.translatePath if six.PY2 else xbmcvfs.translatePath
dialog = xbmcgui.Dialog()

ADDON_ID = 'plugin.video.fanimef'
SELFADDON = xbmcaddon.Addon(id=ADDON_ID)
ADDON_TITLE = 'FANime F'
ADDON_FANART = translatePath(os.path.join('special://home/addons/' + ADDON_ID, 'fanart.jpg'))
ADDON_ICON = translatePath(os.path.join('special://home/addons/' + ADDON_ID, 'icon.png'))
ADDON_DESC = 'FANime F'

KODI_VERSION = float(xbmcaddon.Addon('xbmc.addon').getAddonInfo('version')[:4])

BASE_URL = 'https://animixplay.la'
API_URL = BASE_URL + '/api/search'
SOURCE_API = 'https://play2.echovideo.ru'

USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36'

def get_headers():

    """ Gets headers to send with request """

    headers = {
        "Connection": "keep-alive",
        "Origin" : BASE_URL,
        "x-requested-with": "XMLHttpRequest",
        "Cache-Control": "max-age=0",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "en-US,en;q=0.9,fr;q=0.8",
        "Sec-Ch-Ua" : "Microsoft Edge;v=131, Chromium;v=131, Not_A Brand;v=24",
        "Referer" : BASE_URL + '/?p=movie',
    }

    return headers

def item_set_info( list_item, properties ):

    """
    line item set info
    Fix listitem deprecated warnings
    """

    if KODI_VERSION > 19.8:
        vidtag = list_item.getVideoInfoTag()
        if properties.get( 'title' ):
            vidtag.setTitle( properties.get( 'title' ) )
        if properties.get( 'plot' ):
            vidtag.setPlot( properties.get( 'plot' ) )
        if properties.get( 'tvshowtitle' ):
            vidtag.setTvShowTitle( properties.get( 'tvshowtitle' ) )
        if properties.get( 'season' ):
            vidtag.setSeason( properties.get( 'season' ) )
        if properties.get( 'episode' ):
            vidtag.setEpisode( properties.get( 'episode' ) )
        if properties.get('mediatype'):
            vidtag.setMediaType(properties.get('mediatype'))
    else:
        list_item.setInfo('video', properties)

def menu_get():

    """ Create opening menu """

    addDir( 'Recent', 'recent|0', 4 )
    addDir( 'Dubbed', 'seasonaldub|0', 4 )
    addDir( 'Subbed', 'seasonal|0', 4 )
    addDir( 'Movies', 'movie|0', 2 )
    addDir( 'Genres', BASE_URL, 6 )
    addDir( '[COLOR snow]Search[/COLOR]', 'null', 8 )

def genres(url):

    link = requests.get(url,headers=get_headers()).text
    soup = BeautifulSoup(link, "html.parser")
    content = soup.find_all('div', id={'genreplace'})[0].text
    genres = content.split(',')
    for g in genres:
        addDir(g,'%s|0' %g, 7, description='')

def get_genre_content(url):

    get_args = url.split('|')
    arg1 = get_args[0]
    arg2 = get_args[1]
    data = {
        "genre" : arg1,
        "page" : arg2,
        "orderby" : "popular",
    }

    link = requests.post(API_URL,data=data,headers=get_headers()).json()

    for d in link['result']:
        title = d['title']
        media_img = d['picture']
        media_url = BASE_URL + d['url']
        addDir(title, media_url, 5, media_img, description='', dir_type='link' )

    try:
        gen_next = int(arg2) + 1
        next_page = '%s|%s' %(arg1,gen_next)
        addDir('[B]Next Page -->[/B]', next_page, 7, description='Next Page')
    except Exception:
        pass

def search():

    string =''
    keyboard = xbmc.Keyboard(string, 'What Would You Like To Search For?')
    keyboard.doModal()
    if keyboard.isConfirmed():
        string = keyboard.getText()
        if len(string)>1:
            string = string.replace(' ','%20')
            filter_search(string)
        else:
            dialog.notification(ADDON_TITLE, '[COLOR gold]No Term Entered[/COLOR]', ADDON_ICON, 2500)
    else:
        dialog.notification(ADDON_TITLE, '[COLOR gold]Search Cancelled[/COLOR]', ADDON_ICON, 2500)

def filter_search(search):

    data = {
        "q2" : "%s" % search,
        "origin" : "1",
        "d" : "gogoanime.tel",
    }
    link = requests.post(API_URL,headers=get_headers(),data=data).json()
    data = link['result']
    soup = BeautifulSoup(data, "html.parser")
    found = soup.find_all('li')

    for items in found:
        title = items.a['title']
        media_img = items.img['src']
        links = items.a['href']
        media_url = BASE_URL + links
        addDir(title,media_url,5,media_img, description='', dir_type='link')

def content_main(url):

    get_args = url.split('|')
    arg1 = get_args[0]
    arg2 = get_args[1]
    data = { arg1 : arg2 }
    link = requests.post(API_URL,data=data,headers=get_headers()).json()
    for d in link['result']:
        title = d['title']
        media_img = d['picture']
        media_url = BASE_URL + d['url']
        addDir(title,media_url,3,media_img,description='', dir_type='link')

    try:
        gen_next = int(arg2) + 1
        next_page = '%s|%s' %(arg1,gen_next)
        addDir('[B]Next Page -->[/B]', next_page, 2, description='Next Page')
    except Exception:
        pass

def play_movies(name, url, iconimage):

    link = requests.get(url,headers=get_headers()).text
    data = str(link)
    data = data.encode('ascii', 'ignore').decode('ascii')
    soup = BeautifulSoup(data, "html.parser")
    content = json.loads(soup.find_all('div', id={'epslistplace'})[0].text)
    media = content.get('1')
    get_key = media.replace(SOURCE_API + '/embed-3/', '')
    source = resolve_echo( get_key )
    list_item = xbmcgui.ListItem(name)
    list_item.setArt({"thumb": iconimage})
    list_item.setProperty('IsPlayable', 'true')
    item_set_info( list_item, {'Plot': ADDON_DESC} )

    play_item( list_item, source )

def content_all(url):

    get_args = url.split('|')
    arg1 = get_args[0]
    arg2 = get_args[1]
    data = {arg1: arg2}
    link = requests.post(API_URL,data=data,headers=get_headers()).json()
    for d in link['result']:
        title = d['title']
        media_img = d['picture']
        media_url = BASE_URL + d['url']
        addDir(title, media_url, 5, media_img, description='', dir_type='link')

    try:
        gen_next = int(arg2) + 1
        next_page = '%s|%s' %(arg1,gen_next)
        addDir('[B]Next Page -->[/B]', next_page, 2, description='Next Page')
    except Exception:
        pass

def Play_All( name, url, iconimage ):

    link = requests.get(url,headers=get_headers()).text
    data = str(link)
    data = data.encode('ascii', 'ignore').decode('ascii')
    soup = BeautifulSoup(data, "html.parser")
    content = json.loads(soup.find_all('div', id={'epslistplace'})[0].text)
    names = []
    srcs  = []
    if content:
        for episode, url in content.items():
            if episode == 'eptotal':
                continue
            title = 'Episode : ' + str( episode )
            get_key = url.replace(SOURCE_API + '/embed-3/', '')
            names.append(title)
            srcs.append(get_key)

    selected = dialog.select('Select an Episode.',names)

    if selected < 0:
        dialog.notification(ADDON_TITLE, 'No Source Selected', ADDON_ICON, 2500)
        quit()
    else:
        source = resolve_echo( get_key )
        list_item = xbmcgui.ListItem(name)
        list_item.setArt({"thumb": iconimage})
        list_item.setProperty('IsPlayable', 'true')
        item_set_info( list_item, {'Plot': ADDON_DESC} )

        play_item( list_item, source )

def resolve_echo( token, type='hs' ):

    video_types = [ 'hs', 'sbv2' ]
    if type not in video_types:
        type = video_types[0]

    try:
        source_html = requests.get(SOURCE_API + '/' + type + '/' + token, headers=get_headers()).text
        if source_html and 'id="sources"' in source_html:
            soup = BeautifulSoup(source_html, 'html.parser')
            sources = json.loads(soup.find_all('div', id={'sources'})[0].text)
            if sources:
                return sources.get('sources', '')
    except Exception:
        return ''

    return ''

def play_item( list_item, url ):

    MEDIA_HEADERS = {
        'Referer': SOURCE_API + '/',
        'User-Agent': USER_AGENT,
    }

    if '.m3u8' in url:

        list_item.setPath(url)
        # Disable Kodi's MIME-type request, since we already know what it is.
        list_item.setContentLookup(False)
        list_item.setMimeType('application/vnd.apple.mpegurl')

        if KODI_VERSION < 19:
            list_item.setProperty('inputstreamaddon', 'inputstream.adaptive')
        else:
            list_item.setProperty('inputstream', 'inputstream.adaptive')

        list_item.setProperty('inputstream.adaptive.stream_headers', '&'.join(key+'='+urllib_parse.quote_plus(val) for key, val in MEDIA_HEADERS.items()))
        #list_item.setProperty('inputstream.adaptive.stream_params', '&'.join(key+'='+urllib_parse.quote_plus(val) for key, val in MEDIA_HEADERS.items()))
        list_item.setProperty('inputstream.adaptive.manifest_headers', '&'.join(key+'='+urllib_parse.quote_plus(val) for key, val in MEDIA_HEADERS.items()))

        if KODI_VERSION < 22:
            list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        list_item.setProperty('inputstream.adaptive.original_audio_language', 'en')
        list_item.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive')
        #item.setProperty('inputstream.adaptive.config', '{"ssl_verify_peer":false}')
    else:
        list_item.setPath(url + '|' + '&'.join(key+'='+urllib_parse.quote_plus(val) for key, val in MEDIA_HEADERS.items()))
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, list_item)

def addDir( name, url, mode, iconimage=None, fanart=None, description=None, dir_type="dir" ):

    if iconimage is None:
        iconimage = ADDON_ICON

    if fanart is None:
        fanart = ADDON_FANART

    if description is None:
        description = ADDON_DESC

    folder=True

    u = "%s?url=%s&mode=%s&name=%s&iconimage=%s&fanart=%s&description=%s" % (sys.argv[0], quote_plus(url), mode, quote_plus(name), quote_plus(iconimage), quote_plus(fanart), quote_plus(description))
    ok=True
    list_item=xbmcgui.ListItem(name.strip())
    list_item.setArt({'icon': iconimage, 'thumb': iconimage, 'poster': iconimage})
    item_set_info( list_item, {'title': name.strip(), 'plot': description} )

    if dir_type == "link":
        folder=False
        list_item.setProperty('IsPlayable', 'true')

    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=list_item,isFolder=folder)
    return ok

params = dict(parse_qsl(sys.argv[2].replace("?", "")))
site = params.get("site", "0")
url = params.get("url", "0")
name = params.get("name", "0")
mode = int(params.get("mode", "0"))
iconimage = params.get("iconimage", "0")
fanart = params.get("fanart", "0")
description = params.get("description", "0")

if mode==0 or url=="0" or len(url)<1:
    menu_get()
elif mode==2:
    content_main(url)
elif mode==3:
    play_movies(name, url, iconimage)
elif mode==4:
    content_all(url)
elif mode==5:
    Play_All(name, url, iconimage)
elif mode==6:
    genres(url)
elif mode==7:
    get_genre_content(url)
elif mode==8:
    search()

if mode is None or url is None or len(url)<1:
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=False)
else:
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
