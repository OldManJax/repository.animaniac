# Rerouting
Rerouting is a simple routing module that supports regular expressions. It is made for [Kodi](https://kodi.tv/) to simplify the plugin development.