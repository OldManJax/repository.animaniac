import os
import re
import sys

import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import xbmcvfs

import requests
import resolveurl
import six

from six.moves.urllib.parse import parse_qs, quote_plus, urlparse, parse_qsl
from bs4 import BeautifulSoup

translatePath = xbmc.translatePath if six.PY2 else xbmcvfs.translatePath
dialog = xbmcgui.Dialog()

ADDON_ID = 'plugin.video.fanimef'
SELFADDON = xbmcaddon.Addon(id=ADDON_ID)
ADDON_TITLE = 'FANime F'
ADDON_FANART = translatePath(os.path.join('special://home/addons/' + ADDON_ID, 'fanart.jpg'))
ADDON_ICON = translatePath(os.path.join('special://home/addons/' + ADDON_ID, 'icon.png'))
ADDON_DESC = 'FANime F'

KODI_VERSION = float(xbmcaddon.Addon('xbmc.addon').getAddonInfo('version')[:4])

BASE_URL = 'https://www9.gogoanime.me'
AJAX_URL = 'https://ajax.gogocdn.net'
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'

def get_headers():
    headers = {
        "Connection": "keep-alive",
        "Cache-Control": "max-age=0",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "en-US,en;q=0.9,fr;q=0.8",
        "Sec-Ch-Ua" : "Microsoft Edge;v=131, Chromium;v=131, Not_A Brand;v=24",
        "Referer" : BASE_URL + '/'
    }
    return headers

def item_set_info( line_item, properties ):

    """
    line item set info
    Fix listitem deprecated warnings
    """

    if KODI_VERSION > 19.8:
        vidtag = line_item.getVideoInfoTag()
        if properties.get( 'title' ):
            vidtag.setTitle( properties.get( 'title' ) )
        if properties.get( 'plot' ):
            vidtag.setPlot( properties.get( 'plot' ) )
        if properties.get( 'tvshowtitle' ):
            vidtag.setTvShowTitle( properties.get( 'tvshowtitle' ) )
        if properties.get( 'season' ):
            vidtag.setSeason( properties.get( 'season' ) )
        if properties.get( 'episode' ):
            vidtag.setEpisode( properties.get( 'episode' ) )
        if properties.get('mediatype'):
            vidtag.setMediaType(properties.get('mediatype'))
    else:
        line_item.setInfo('video', properties)

def GetMenu():

    addDir( 'Recent Releases', BASE_URL, 2, ADDON_ICON, ADDON_FANART, ADDON_DESC )
    addDir( 'A to Z', BASE_URL + '/anime-list.html', 3, ADDON_ICON, ADDON_FANART, ADDON_DESC )
    addDir( 'Genres', BASE_URL + '/home', 5, ADDON_ICON, ADDON_FANART, ADDON_DESC )
    addDir( 'New Seasons', BASE_URL + '/new-season.html?page=1', 6, ADDON_ICON, ADDON_FANART, ADDON_DESC )
    addDir( 'Ongoing Series', BASE_URL + '/api/ongoing_series', 11, ADDON_ICON, ADDON_FANART, ADDON_DESC )
    addDir( 'Recently Added Series', BASE_URL + '/api/recently_added_series', 11, ADDON_ICON, ADDON_FANART, ADDON_DESC )
    addDir( 'Movies', BASE_URL + '/anime-movies.html?aph=&page=1', 6, ADDON_ICON, ADDON_FANART, ADDON_DESC )
    addDir( 'Popular', BASE_URL + '/popular.html?page=1', 6, ADDON_ICON, ADDON_FANART, ADDON_DESC )
    addDir( '[COLOR snow][B]Search[/B][/COLOR]', 'url', 9, ADDON_ICON, ADDON_FANART, ADDON_DESC )

def Search():

    string =''
    SearchUrl = BASE_URL + ('/search.html?keyword=%s')
    keyboard = xbmc.Keyboard(string, 'What Would You Like To Search For?')
    keyboard.doModal()
    if keyboard.isConfirmed():
        string = keyboard.getText()
        if len(string)>1:
            string = string.replace(' ','-')
            Search = (SearchUrl %string)
            MainContent(Search)
        else:
            dialog.notification(ADDON_TITLE, '[COLOR gold]No Term Entered[/COLOR]', ADDON_ICON, 2500)
    else:
        dialog.notification(ADDON_TITLE, '[COLOR gold]Search Cancelled[/COLOR]', ADDON_ICON, 2500)

def GetApiContent(url):

    link = requests.get(url,headers=get_headers()).text
    pattern = r'''['"]p['"].*?['"](.*?)['"]'''
    get_all = re.findall(pattern,link)
    for data in get_all:
        title = data.replace('-',' ').title()
        url2 = (BASE_URL + '/category/%s' % data)
        addDir( title, url2, 10, ADDON_ICON, ADDON_FANART, description='' )

def Recent(url):

    link = requests.get(url,headers=get_headers()).text
    soup = BeautifulSoup(link,'html.parser')
    data = soup.find('div', class_={'last_episodes'})

    for i in data.find_all('li'):
        name = i.a['title']
        name = name.encode("utf8") if six.PY2 else name
        url2 = i.a['href']
        url2 = BASE_URL + url2 if url2.startswith('/') else url2
        icon = i.find('img')
        icon = str(icon['src'])
        icon = BASE_URL + icon if icon.startswith('/') else icon
        epi = i.find('p', class_={'episode'}).text
        epi = epi.encode("utf8") if six.PY2 else epi
        addLink( '%s | %s' % (name,epi), url2, 20, icon, ADDON_FANART, description='' )

def ATOZ(url):

    link = requests.get(url,headers=get_headers()).text
    soup = BeautifulSoup(link,'html.parser')
    data = soup.find_all('li', class_={'first-char'})

    for i in data:
        name = i.a.text
        url2 = i.a['href']
        url2 = BASE_URL + url2 if url2.startswith('/') else url2
        addDir('%s' % name,url2,4,ADDON_ICON,ADDON_FANART,ADDON_DESC)

def ATOZContent(url):

    if not '?page=' in url:
        url = ('%s?page=1' %url)
    link = requests.get(url,headers=get_headers()).text
    soup = BeautifulSoup(link,'html.parser')
    data = soup.find('ul', class_={'listing'})

    for i in data:
        try:
            name = i.a['title']
            if name =='':
                name = i.a.text
            name = name.encode("utf8") if six.PY2 else name
            url2 = i.a['href']
            url2 = BASE_URL + url2 if url2.startswith('/') else url2
            try:
                icon = re.findall(r'''img\s+src=['"](.*?)['"]''',str(i))[0]
            except Exception:
                icon = ADDON_ICON
            addDir( '%s' % name, url2, 10, icon, ADDON_FANART, ADDON_DESC )
        except Exception:
            pass
    try:
        Getpage = url.split('?page=')[1]
        BasePage = url.split('?page=')[0]
        GenNext = int(Getpage) + 1
        NextPage = ('%s?page=%s' %(BasePage,GenNext))
        addDir( '[COLOR gold][B]Next Page -->[/B][/COLOR]', NextPage, 4, ADDON_ICON, ADDON_FANART, 'Next Page' )
    except Exception:
        pass

def GetShowContent( url, iconimage ):

    headers = {'User-Agent': USER_AGENT}
    link = requests.get(url,headers=get_headers()).text
    soup = BeautifulSoup(link,'html.parser')
    try:
        ShowIcon = soup.find("meta",  property="og:image")['content']
    except Exception:
        ShowIcon = ADDON_ICON
    ShowDescription = soup.find_all('p', class_={'type'})
    DescText = ''
    EpiID = re.findall(r'''value=['"](.*?)['"]\sid=['"]movie_id''',link)[0]
    AjaxUrl = AJAX_URL + ('/ajax/load-list-episode?ep_start=1&ep_end=1000&id=%s' % EpiID)
    for d in ShowDescription:
        try:
            DescText = DescText + d.text+('\n')
        except Exception:
            DescText = 'No Description Available'
        DescText = DescText.encode("utf8") if six.PY2 else DescText
    GetEpisodes = requests.get(AjaxUrl,headers=headers).text
    soup2 = BeautifulSoup(GetEpisodes,'html.parser')
    if len(soup2) == 0:
        dialog.notification(AddonTitle, '[COLOR yellow]Sorry No Links Available[/COLOR]', Addonicon, 2500)
        quit()

    for i in soup2.find_all('a'):
        try:
            name = i.find('div',class_={'name'}).text
            name = name.replace('\n',' ').strip()
            name = name.encode("utf8") if six.PY2 else name
            url2 = i['href'].strip()
            url2 = BASE_URL + url2 if url2.startswith('/') else url2
            addLink( '%s' % name, url2, 20, iconimage, ADDON_FANART, DescText )
        except Exception:
            pass

def Genre(url):

    link = requests.get(url,headers=get_headers()).text
    soup = BeautifulSoup(link,'html.parser')
    data = soup.find('li', class_={'movie genre hide'})
    if data:
        for i in data.find_all('a'):
            try:
                name = i['title']
                name = name.encode("utf8") if six.PY2 else name
                url2 = i['href']
                url2 = BASE_URL + url2 if url2.startswith('/') else url2
                addDir('%s' % name, url2+'?page=1', 6, ADDON_ICON, ADDON_FANART, ADDON_DESC )
            except Exception:
                pass

def MainContent(url):

    name = ''

    link = requests.get(url,headers=get_headers()).text
    soup = BeautifulSoup(link,'html.parser')
    data = soup.find('ul', class_={'items'})
    for i in data.find_all('li'):
        name = i.a['title']
        name = name.encode("utf8") if six.PY2 else name
        url2 = i.a['href']
        url2 = BASE_URL + url2 if url2.startswith('/') else url2
        icon = i.img['src']

        if not BASE_URL in icon:
            icon = BASE_URL + icon

        addDir('%s' % name,url2,10,icon,ADDON_FANART,description='')

    try:
        Getpage = url.split('page=')[-1]
        BasePage = url.rsplit('page=', 1)[0]
        GenNext = int(Getpage) + 1
        NextPage = ('%spage=%s' %(BasePage,GenNext))
        addDir('[COLOR gold][B]Next Page -->[/B][/COLOR]',NextPage,6,ADDON_ICON,ADDON_FANART,'Next Page')
    except Exception:
        pass

    if 'search.html' in url and name == '':
        name = 'Sorry No Items Found'
        addLink('%s' % name,'url2',9999,ADDON_ICON,ADDON_FANART,description='')

def OnGoing(url):

    link = requests.get(url,headers=get_headers()).text
    soup = BeautifulSoup(link,'html.parser')
    data = soup.find("div", class_={'overview'})
    for i in data.find_all('li'):
        name = i.a['title']
        name = name.encode("utf8") if six.PY2 else name
        url2 = i.a['href']
        url2 = BASE_URL + url2 if url2.startswith('/') else url2
        addDir('%s' % name,url2,10,ADDON_ICON,ADDON_FANART,description='')

def RecentlyAdded(url):

    link = requests.get(url,headers=get_headers()).text
    soup = BeautifulSoup(link,'html.parser')
    data = soup.find("div", class_={'added_series_body final'})
    for i in data.find_all('li'):
        name = i.a['title']
        name = name.encode("utf8") if six.PY2 else name
        url2 = i.a['href']
        url2 = BASE_URL + url2 if url2.startswith('/') else url2
        addDir('%s' % name,url2,10,ADDON_ICON,ADDON_FANART,description='')

def LinkGetter(name, url, iconimage, description):

    link = requests.get(url,headers=get_headers()).text
    soup = BeautifulSoup(link,'html.parser')
    source = soup.find('div', class_={'anime_muti_link'})
    names = []
    srcs  = []
    linksfound = 0
    for i in source.find_all('a'):
        source = i['data-video']
        try:
            if resolveurl.HostedMediaFile(source).valid_url():
                linksfound +=1
                names.append("Link %s" % linksfound)
                srcs.append(source)
        except Exception:
            pass
    selected = dialog.select('Select a link.',names)
    if selected < 0:
        kodi.notify(msg='No option selected.')
        kodi.idle()
        quit()
    else:
        url3 = srcs[selected]
        hmf = resolveurl.HostedMediaFile(url3)
        if hmf.valid_url():
            link = hmf.resolve()
        if not 'user-agent' in link.lower():
            link = link + '|User-Agent=' + quote_plus( USER_AGENT )
        xbmc.log( link, xbmc.LOGWARNING )
        list_item = xbmcgui.ListItem(name)
        list_item.setPath(link)
        list_item.setArt({'icon': iconimage, 'thumb': iconimage, 'poster': iconimage})
        item_set_info( list_item, {'title': name, 'plot': description} )
        xbmc.log( "here", xbmc.LOGWARNING )
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, list_item)
        quit()

def PLAYLINK(name, link, iconimage):
    dialog.notification(ADDON_TITLE, '[COLOR yellow]Hunting Link Now Be Patient[/COLOR]', ADDON_ICON, 2500)
    try:
        hmf = resolveurl.HostedMediaFile(url)
        if hmf.valid_url():
            link = hmf.resolve()
        if not 'user-agent' in link.lower():
            link = link + '|User-Agent=' + quote_plus( USER_AGENT )
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, xbmcgui.ListItem(path=link))
        quit()
    except Exception as e:
        dialog.notification(ADDON_TITLE,"[COLOR yellow][B]%s[/B][/COLOR]" % e,ADDON_ICON,5000)
        quit()

def addDir( name, url, mode, iconimage, fanart, description='' ):
    u = "%s?url=%s&mode=%s&name=%s&iconimage=%s&fanart=%s&description=%s" % (sys.argv[0], quote_plus(url), mode, quote_plus(name), quote_plus(iconimage), quote_plus(fanart), quote_plus(description))
    ok=True
    list_item=xbmcgui.ListItem(name)
    list_item.setArt({'icon': iconimage, 'thumb': iconimage, 'poster': iconimage})
    item_set_info( list_item, {'title': name, 'plot': description} )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=list_item,isFolder=True)
    return ok

def addLink(name, url, mode, iconimage, fanart, description='', family=''):
    u = "%s?url=%s&mode=%s&name=%s&iconimage=%s&fanart=%s&description=%s" % (sys.argv[0], quote_plus(url), mode, quote_plus(name), quote_plus(iconimage), quote_plus(fanart), quote_plus(description))
    ok=True
    liz=xbmcgui.ListItem(name)
    liz.setArt({"thumb": iconimage})
    liz.setInfo('video', {'Plot': description})
    liz.setProperty('IsPlayable', 'true')
    StartParty="%s?url=%s&mode=%s&name=%s&iconimage=%s&fanart=%s&description=%s" % (sys.argv[0], quote_plus(url), '3000', quote_plus(name), quote_plus(iconimage), quote_plus(fanart), quote_plus(description))
    liz.addContextMenuItems([('[COLOR yellow][B]Start A Watch Party For %s[/B][/COLOR]' %name, 'xbmc.RunPlugin('+StartParty+')')])
    view=xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

params = dict(parse_qsl(sys.argv[2].replace("?", "")))
site = params.get("site", "0")
url = params.get("url", "0")
name = params.get("name", "0")
mode = int(params.get("mode", "0"))
iconimage = params.get("iconimage", "0")
fanart = params.get("fanart", "0")
description = params.get("description", "0")

if mode==0 or url=="0" or len(url)<1:
    GetMenu()
elif mode==2:
    Recent(url)
elif mode==3:
    ATOZ(url)
elif mode==4:
    ATOZContent(url)
elif mode==5:
    Genre(url)
elif mode==6:
    MainContent(url)
elif mode==7:
    OnGoing(url)
elif mode==8:
    RecentlyAdded(url)
elif mode==9:
    Search()
elif mode==10:
    GetShowContent(url, iconimage)
elif mode==11:
    GetApiContent(url)
elif mode==20:
    LinkGetter(name, url, iconimage, description)
elif mode==99:
    PLAYLINK(name, url, iconimage)

if mode is None or url is None or len(url)<1:
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=False)
else:
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
