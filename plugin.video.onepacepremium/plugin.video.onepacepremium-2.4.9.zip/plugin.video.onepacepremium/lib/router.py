import sys
from importlib import import_module
from urllib import parse

import xbmc

from .utils import log, reset_for_invocation


# Each action names the module and function it lives in.
_ACTIONS = {
    "show_changelog":      "changelog:show_changelog",
    "export_settings":     "backup:export_settings",
    "import_settings":     "backup:import_settings",
    "open_addon_settings": "route_common:open_addon_settings",
    "play_trailer":        "route_common:play_trailer",
    "list_catalog_type":   "catalog_routes:list_catalog_type",
    "list_catalog":        "catalog_routes:list_catalog",
    "search_catalog":      "catalog_routes:search_catalog",
    "list_browse":         "catalog_routes:list_browse",
    "list_seasons":        "episode_routes:list_seasons",
    "list_episodes":       "episode_routes:list_episodes",
    "check_resume":        "episode_routes:check_resume",
    "get_streams":         "episode_routes:get_streams",
    "mark_watched":        "episode_routes:mark_watched",
    "clear_progress":      "episode_routes:clear_progress",
    "play_video":          "playback:play_video",
    "list_my_lists":       "my_lists:list_my_lists",
    "list_in_progress":    "my_lists:list_in_progress",
    "list_next_episodes":  "my_lists:list_next_episodes",
    "list_downloads":      "downloads:list_downloads",
    "list_on_device":      "downloads:list_on_device",
    "list_manage":         "downloads:list_manage",
    "open_downloads_manager": "downloads_manager:show",
    "download_episode":    "episode_routes:download_episode",
    "download_season":     "episode_routes:download_season",
    "delete_download":     "downloads:delete",
    "move_downloads":      "downloads:move_downloads",
    "browse_download":     "downloads:browse",
    "show_download_report": "downloads:show_report",
    "check_updates":       "downloads:check_updates",
    "fetch_artwork":       "downloads:fetch_artwork",
    "rescan_downloads":    "downloads:rescan",
    "import_folder":       "import_folder:run",
    "choose_invoker":      "invoker:choose",
}


def _resolve(target):
    """Import the one module this action lives in."""
    module, _, name = target.partition(":")
    return getattr(import_module(f".{module}", __package__), name)


def addon_router():
    reset_for_invocation()
    param_string = sys.argv[2][1:]

    if param_string:
        params = dict(parse.parse_qsl(param_string))
        action = params.get("action")
        target = _ACTIONS.get(action)
        if target:
            _resolve(target)(params)
            return

    log("Opening root menu", xbmc.LOGINFO)
    _resolve("catalog_routes:list_root")()
