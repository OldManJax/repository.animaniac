import base64
import glob
import json
import os
import sqlite3
import sys

import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "plugin.video.onepacepremium"
# Launched with RunScript, so it carries its own copy of the name.
ADDON_NAME = "One Pace Addon"

# Launched with RunScript, so it cannot import from the package.
DEFAULT_DOWNLOAD_FOLDER = f"special://profile/addon_data/{ADDON_ID}/downloads/"

# ISO 639-2/B codes used by the subtitles feed.
LANG_NAMES = {
    "ara": "Arabic",     "cze": "Czech",      "dut": "Dutch",
    "eng": "English",    "fin": "Finnish",    "fre": "French",
    "ger": "German",     "heb": "Hebrew",     "ind": "Indonesian",
    "ita": "Italian",    "jpn": "Japanese",   "pol": "Polish",
    "por": "Portuguese", "rus": "Russian",    "spa": "Spanish",
    "tur": "Turkish",    "vie": "Vietnamese",
}


# config key, bingeGroup code, display label
SERVICES = (
    ("realdebrid", "rd",  "Real-Debrid"),
    ("premiumize", "pm",  "Premiumize"),
    ("debridlink", "dl",  "DebridLink"),
    ("torbox",     "tb",  "TorBox"),
    ("alldebrid",  "ad",  "AllDebrid"),
    ("p2p",        "p2p", "Torrent"),
)


def _profile():
    p = xbmcvfs.translatePath(xbmcaddon.Addon(ADDON_ID).getAddonInfo("profile"))
    return p if p.endswith(("/", "\\")) else p + "/"


def clear_cache():
    dialog = xbmcgui.Dialog()
    if not dialog.yesno(
        "Clear API Cache",
        "This will delete all cached metadata. The addon will fetch fresh data on the next browse.\n\nAre you sure?",
        nolabel="No",
        yeslabel="Yes",
    ):
        return

    profile = _profile()
    _, files = xbmcvfs.listdir(profile)
    count = sum(
        1 for f in files
        if f.startswith("cache_") and f.endswith(".json") and xbmcvfs.delete(profile + f)
    )
    dialog.notification(
        ADDON_NAME,
        f"API cache cleared ({count} file{'s' if count != 1 else ''} removed).",
        xbmcgui.NOTIFICATION_INFO, 5000, False,
    )


def clear_subs_cache():
    dialog = xbmcgui.Dialog()
    if not dialog.yesno(
        "Clear Subtitle Cache",
        "This will delete all cached subtitle files. They will be fetched again on the next playback.\n\nAre you sure?",
        nolabel="No",
        yeslabel="Yes",
    ):
        return

    root = "special://temp/onepace-subs/"
    count = 0
    if xbmcvfs.exists(root):
        # One folder per episode, files inside — no deeper nesting.
        for folder in xbmcvfs.listdir(root)[0]:
            path = f"{root}{folder}/"
            for name in xbmcvfs.listdir(path)[1]:
                if xbmcvfs.delete(path + name):
                    count += 1
            xbmcvfs.rmdir(path)

    dialog.notification(
        ADDON_NAME,
        f"Subtitle cache cleared ({count} file{'s' if count != 1 else ''} removed).",
        xbmcgui.NOTIFICATION_INFO, 5000, False,
    )


def _clear_kodi_bookmarks():
    """Clear Kodi's own bookmark (resume) entries for our plugin from MyVideos.db."""
    try:
        db_dir = xbmcvfs.translatePath("special://profile/Database/")
        db_files = sorted(glob.glob(os.path.join(db_dir, "MyVideos*.db")), reverse=True)
        if not db_files:
            return 0
        con = sqlite3.connect(db_files[0])
        cur = con.cursor()
        cur.execute(
            "SELECT idFile FROM files WHERE strFilename LIKE ?",
            ("%plugin.video.onepacepremium%",)
        )
        file_ids = [str(r[0]) for r in cur.fetchall()]
        count = 0
        if file_ids:
            ph = ",".join(file_ids)
            cur.execute(f"DELETE FROM bookmark WHERE idFile IN ({ph})")
            count = cur.rowcount
            con.commit()
        cur.close()
        con.close()
        return count
    except Exception:
        return 0


def clear_bookmarks():
    dialog = xbmcgui.Dialog()
    if not dialog.yesno(
        "Clear Bookmarks",
        "This will remove all saved resume positions. Your watched history will not be affected.\n\nAre you sure?",
        nolabel="No",
        yeslabel="Yes",
    ):
        return

    path = _profile() + "bookmarks.json"
    if xbmcvfs.exists(path):
        xbmcvfs.delete(path)
    _clear_kodi_bookmarks()
    dialog.notification(
        ADDON_NAME,
        "All resume bookmarks cleared.",
        xbmcgui.NOTIFICATION_INFO, 5000, False,
    )


def _reset_kodi_playcounts():
    """Reset Kodi's playCount to 0 for all our plugin's file entries in MyVideos.db."""
    try:
        db_dir = xbmcvfs.translatePath("special://profile/Database/")
        db_files = sorted(glob.glob(os.path.join(db_dir, "MyVideos*.db")), reverse=True)
        if not db_files:
            return
        con = sqlite3.connect(db_files[0])
        cur = con.cursor()
        cur.execute(
            "UPDATE files SET playCount=0 WHERE strFilename LIKE ?",
            ("%plugin.video.onepacepremium%",)
        )
        con.commit()
        cur.close()
        con.close()
    except Exception:
        pass


def clear_watched():
    dialog = xbmcgui.Dialog()
    if not dialog.yesno(
        "Clear Watched History",
        "This will permanently erase all watched episode data. This cannot be undone.\n\nAre you sure?",
        nolabel="No",
        yeslabel="Yes, clear all",
    ):
        return

    path = _profile() + "watched.json"
    if xbmcvfs.exists(path):
        xbmcvfs.delete(path)
    _reset_kodi_playcounts()
    dialog.notification(
        ADDON_NAME,
        "Watched history cleared.",
        xbmcgui.NOTIFICATION_INFO, 5000, False,
    )


def _parse_config(config):
    """Parse the config string into service keys (empty = unrecognized)."""
    _LEGACY_PREFIXES = [
        ("rdkey=",      "realdebrid"),
        ("torbox=",     "torbox"),
        ("alldebrid=",  "alldebrid"),
        ("premiumize=", "premiumize"),
        ("dlkey=",      "debridlink"),
    ]
    _LEGACY_KEYS = {
        "rdkey":      "realdebrid",
        "torbox":     "torbox",
        "alldebrid":  "alldebrid",
        "premiumize": "premiumize",
        "dlkey":      "debridlink",
    }
    _SERVICE_LABELS = {key: key for key, _, _ in SERVICES}
    # P2P carries no apiKey; every debrid service must have one.
    _KEYLESS = {"p2p"}

    if not config:
        return []

    # 1. Legacy plaintext: rdkey=..., torbox=..., etc.
    for prefix, label in _LEGACY_PREFIXES:
        if config.startswith(prefix):
            return [label] if config[len(prefix):] else []

    try:
        decoded = json.loads(base64.b64decode(config).decode("utf-8"))

        # 2. Multi-service: a debridServices list of service and apiKey.
        if isinstance(decoded.get("debridServices"), list):
            seen = set()
            labels = []
            for entry in decoded["debridServices"]:
                if not isinstance(entry, dict):
                    continue  # skip a malformed entry, keep the valid ones
                svc = entry.get("service", "")
                key = entry.get("apiKey", "")
                label = _SERVICE_LABELS.get(svc)
                if not label or label in seen:
                    continue
                if svc not in _KEYLESS and not key:
                    continue
                seen.add(label)
                labels.append(label)
            return labels

        # 3. Legacy base64 JSON: {"rdkey": "..."}
        labels = []
        seen = set()
        for field, label in _LEGACY_KEYS.items():
            if decoded.get(field) and label not in seen:
                seen.add(label)
                labels.append(label)
        return labels

    except Exception:
        pass

    return []


def service_labels(keys):
    labels = {key: label for key, _, label in SERVICES}
    return [labels.get(k, k) for k in keys]


def show_status():
    config = xbmcaddon.Addon(ADDON_ID).getSetting("secret_string")
    services = _parse_config(config)

    if not config:
        xbmcgui.Dialog().ok(
            "Account Status",
            "Not configured.\n\nUse [B]Configure / Reconfigure[/B] to set up your account."
        )
        return

    if not services:
        xbmcgui.Dialog().ok(
            "Account Status",
            "Configuration not recognized.\n\nUse [B]Configure / Reconfigure[/B] to set up again."
        )
        return

    connected = " + ".join(f"[B]{s}[/B]" for s in service_labels(services))
    xbmcgui.Dialog().ok(
        "Account Status",
        f"Connected: {connected}"
    )


def configure_account():
    import xbmc
    addon = xbmcaddon.Addon(ADDON_ID)
    config = addon.getSetting("secret_string")
    services = _parse_config(config)

    if not config:
        message = "No account configured yet.\n\nSet up your debrid service to start watching."
        yes_label = "Configure"
    elif not services:
        message = "Configuration not recognized.\n\nReconfigure your account?"
        yes_label = "Reconfigure"
    else:
        connected = " + ".join(f"[B]{s}[/B]" for s in service_labels(services))
        message = f"Connected: {connected}\n\nDo you want to reconfigure?"
        yes_label = "Reconfigure"

    if xbmcgui.Dialog().yesno(
        "Configure / Reconfigure",
        message,
        nolabel="Cancel",
        yeslabel=yes_label,
    ):
        # Close settings first, so auth runs without it behind.
        xbmc.executebuiltin("Dialog.Close(all,true)")
        xbmc.executebuiltin(
            f"RunScript(special://home/addons/{ADDON_ID}/lib/custom_settings_window.py)"
        )


HIGHLIGHT_COLORS = (
    ("Pink", "fff502f4"), ("Cyan", "ff00d4ff"), ("Green", "ff00c853"),
    ("Orange", "ffff8f00"), ("Red", "ffe53935"), ("Purple", "ff8e24aa"),
    ("Yellow", "ffffd600"), ("White", "ffffffff"), ("Grey", "ff9e9e9e"),
)


def _settled():
    """Wait out the window's closing animation, so a value reaches the disk."""
    import xbmc
    monitor = xbmc.Monitor()
    for _ in range(30):
        if not xbmc.getCondVisibility("Window.IsActive(addonsettings)"):
            return True
        if monitor.waitForAbort(0.1):
            return False
    return True


def _save_settings(addon, values):
    """Kodi routes these into the open settings window, which saves them on OK."""
    for key, value in values.items():
        addon.setSetting(key, value)
    return True


def choose_preferred_service():
    """Pick which service to stream from. Only configured ones are offered."""
    addon = xbmcaddon.Addon(ADDON_ID)
    configured = _parse_config(addon.getSetting("secret_string"))
    if not configured:
        xbmcgui.Dialog().ok(
            "Preferred Service",
            "No services configured.\n\nUse [B]Configure / Reconfigure[/B] first."
        )
        return

    codes = {key: code for key, code, _ in SERVICES}
    labels = {key: label for key, _, label in SERVICES}
    options = [(("", "Always ask"))] + [(codes[k], labels[k]) for k in configured if k in codes]

    current = addon.getSetting("preferred_service")
    preselect = next((i for i, (c, _) in enumerate(options) if c == current), 0)

    chosen = xbmcgui.Dialog().select(
        "Preferred Service", [name for _, name in options], preselect=preselect
    )
    if chosen < 0:
        return

    code, name = options[chosen]
    if _save_settings(addon, {"preferred_service": code,
                              "preferred_service_display": name}):
        xbmcgui.Dialog().notification("Preferred Service", name,
                                      xbmcgui.NOTIFICATION_INFO, 5000, False)


def choose_highlight_color():
    """Pick the colour used for the show name in My Lists."""
    addon = xbmcaddon.Addon(ADDON_ID)
    names = [f"[COLOR {hexval}]{name}[/COLOR]" for name, hexval in HIGHLIGHT_COLORS]
    current = addon.getSetting("highlight_color")
    preselect = next((i for i, (_, h) in enumerate(HIGHLIGHT_COLORS) if h == current), 0)

    chosen = xbmcgui.Dialog().select("Show Name Colour", names, preselect=preselect)
    if chosen < 0:
        return

    name, hexval = HIGHLIGHT_COLORS[chosen]
    if _save_settings(addon, {"highlight_color": hexval, "highlight_color_display": name}):
        xbmcgui.Dialog().notification("Show Name Colour", name,
                                      xbmcgui.NOTIFICATION_INFO, 5000, False)


def choose_download_folder():
    """Default or somewhere of your own — and a way back to default."""
    try:
        _pick_download_folder()
    finally:
        # Kodi shut the window to save it, so put the viewer back in it.
        import xbmc
        xbmc.executebuiltin(f"Addon.OpenSettings({ADDON_ID})")


def _pick_download_folder():
    """The pick itself, with the settings window already closed by Kodi."""
    addon = xbmcaddon.Addon(ADDON_ID)
    current = addon.getSetting("download_folder")
    is_default = not current or current == DEFAULT_DOWNLOAD_FOLDER
    chosen = xbmcgui.Dialog().select(
        "Download Folder",
        ["Default  (inside the add-on's own folder)", "Custom..."],
        preselect=0 if is_default else 1,
    )
    if chosen < 0:
        return

    if chosen == 0:
        path, shown = DEFAULT_DOWNLOAD_FOLDER, "Default"
    else:
        start = current if current and current != DEFAULT_DOWNLOAD_FOLDER else ""
        path = xbmcgui.Dialog().browseSingle(3, "Where should downloads go?", "files",
                                             defaultt=start)
        if not path:
            return
        shown = path

    # Rescan and Move read the folder off the disk, so it has to land there.
    _settled()
    if _save_settings(addon, {"download_folder": path,
                              "download_folder_display": shown}):
        xbmcgui.Dialog().notification("Download Folder", shown,
                                      xbmcgui.NOTIFICATION_INFO, 5000, False)


def choose_background():
    """The picture behind our own menus. Kodi's own browser previews images."""
    addon = xbmcaddon.Addon(ADDON_ID)
    current = addon.getSetting("background_image")
    chosen = xbmcgui.Dialog().select(
        "Menu Background",
        ["Default  (the one the add-on ships)", "Custom..."],
        preselect=0 if not current else 1,
    )
    if chosen < 0:
        return

    if chosen == 0:
        path, shown = "", "Default"
    else:
        # Type 2 is Kodi's image browser, and useThumbs previews every picture.
        path = xbmcgui.Dialog().browseSingle(
            2, "Choose a background", "files", "", True, False, current)
        if not path:
            return
        shown = path.rsplit("/", 1)[-1].rsplit("\\", 1)[-1] or path

    if _save_settings(addon, {"background_image": path,
                              "background_display": shown}):
        xbmcgui.Dialog().notification("Menu Background", shown,
                                      xbmcgui.NOTIFICATION_INFO, 5000, False)


def choose_sub_langs():
    """Pick which subtitle languages to show. Empty selection means all."""
    addon = xbmcaddon.Addon(ADDON_ID)
    codes = sorted(LANG_NAMES, key=lambda c: LANG_NAMES[c])
    names = [LANG_NAMES[c] for c in codes]

    current = [c for c in addon.getSetting("sub_langs").split(",") if c]
    preselect = [i for i, c in enumerate(codes) if c in current]

    chosen = xbmcgui.Dialog().multiselect(
        "Subtitle Languages", names, preselect=preselect
    )
    if chosen is None:
        return  # cancelled — leave the current choice alone

    selected = [codes[i] for i in chosen]
    summary = ", ".join(LANG_NAMES[c] for c in selected) if selected else "All languages"

    if _save_settings(addon, {"sub_langs": ",".join(selected),
                              "sub_langs_display": summary}):
        xbmcgui.Dialog().notification(
            "Subtitle Languages", summary,
            xbmcgui.NOTIFICATION_INFO, 5000, False,
        )


if __name__ == "__main__":
    action = sys.argv[1].strip() if len(sys.argv) > 1 else ""
    if action == "clear_cache":
        clear_cache()
    elif action == "clear_subs_cache":
        clear_subs_cache()
    elif action == "clear_bookmarks":
        clear_bookmarks()
    elif action == "clear_watched":
        clear_watched()
    elif action == "show_status":
        show_status()
    elif action == "configure_account":
        configure_account()
    elif action == "choose_download_folder":
        choose_download_folder()
    elif action == "choose_sub_langs":
        choose_sub_langs()
    elif action == "choose_highlight_color":
        choose_highlight_color()
    elif action == "choose_background":
        choose_background()
    elif action == "choose_preferred_service":
        choose_preferred_service()
