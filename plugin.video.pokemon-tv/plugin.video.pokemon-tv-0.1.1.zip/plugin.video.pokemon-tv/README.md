# Kodi Pokémon TV

This addon allows you watch Pokémon TV with Kodi.
It uses the offical API https://www.pokemon.com/api/pokemontv/v2/channels/us/
as used by https://watch.pokemon.com .

You can configure the stream quality and language in the addons settings.

# Disclaimer
Pokémon is a trademark owned by Nintendo, Creatures Inc. and Game Freak.
All content is owned by The Pokémon Company International.
  
This addon utilizes services provided under the terms-of-use found at
https://www.pokemon.com/us/terms-of-use/ .
The applicable TOS may vary based on your location.
