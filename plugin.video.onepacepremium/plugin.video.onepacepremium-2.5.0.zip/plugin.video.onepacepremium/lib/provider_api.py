import re
import time
from typing import Optional, Tuple
from urllib import parse

from . import cache as _cache
from .utils import (build_url, fetch_data, get_catalog_provider_url,
                    get_setting, log)

SERIES_CATALOG_EXCLUDED_NAMES = {"last videos", "calendar videos"}

# Not in the feed, but constant for the source series.
SERIES_STUDIOS = ["Toei Animation", "Fuji TV"]

_YEAR_RE = re.compile(r"\d{4}")
_AIR_DATE_RE = re.compile(r"^(\d{4}-\d{2}-\d{2})")
_CATALOG_PRIORITY_MAP = {"popular": 0, "new": 1, "featured": 2}
_PROVIDER_CONTEXT_CACHE: Optional[Tuple[str, str]] = None


def _compose_url(base_url: str, path: str):
    return parse.urljoin(base_url.rstrip("/") + "/", path.lstrip("/"))


def _provider_context():
    global _PROVIDER_CONTEXT_CACHE
    if _PROVIDER_CONTEXT_CACHE is not None:
        return _PROVIDER_CONTEXT_CACHE

    configured = get_catalog_provider_url()
    if configured.endswith("/manifest.json"):
        context = (configured, configured[: -len("/manifest.json")])
    elif configured.endswith(".json"):
        context = (configured, configured.rsplit("/", 1)[0])
    else:
        context = (f"{configured}/manifest.json", configured)

    _PROVIDER_CONTEXT_CACHE = context
    return context


def _provider_path(value: str):
    return parse.quote(str(value), safe="")


def _fetch_provider_manifest():
    manifest_url, _ = _provider_context()
    cached = _cache.get(manifest_url)
    if cached is not None:
        return cached
    data = fetch_data(manifest_url)
    if data is not None:
        _cache.set(manifest_url, data, 86400)
    return data


def _fetch_catalog(url: str):
    cached = _cache.get(url)
    if cached is not None:
        return cached
    data = fetch_data(url)
    if data is not None:
        _cache.set(url, data, 86400)
    return data


def _meta_url(catalog_type: str, video_id: str):
    _, provider_base_url = _provider_context()
    return _compose_url(
        provider_base_url,
        f"meta/{_provider_path(catalog_type)}/{_provider_path(video_id)}.json",
    )


def _fetch_provider_meta(catalog_type: str, video_id: str):
    url = _meta_url(catalog_type, video_id)
    cached = _cache.get(url)
    if cached is not None:
        return cached or None
    response = fetch_data(url)
    meta = response["meta"] if response else None
    # A short memory of failure: the prefetch and the per-series call would
    # otherwise both pay for it, and the second one tells us nothing new.
    _cache.set(url, meta if meta is not None else False, 21600 if meta else 60)
    return meta


def _prefetch_metas(catalog_type: str, video_ids):
    """Warm the meta cache in parallel so the per-id calls below hit it."""
    _provider_context()  # resolve once here, not from the threads
    missing = [
        vid for vid in dict.fromkeys(video_ids)
        if vid and _cache.get(_meta_url(catalog_type, vid)) is None
    ]
    if len(missing) < 2:
        return
    from concurrent import futures
    started = time.time()
    with futures.ThreadPoolExecutor(max_workers=8) as pool:
        list(pool.map(lambda vid: _fetch_provider_meta(catalog_type, vid), missing))
    log(f"[meta] prefetched {len(missing)} series in {time.time() - started:.2f}s")


def episode_play_url(video, meta, series_id, catalog_type="series",
                     season_poster="", episode_id=None, autoplay=False):
    """The check_resume URL for one episode, with the art and labels playback needs."""
    from .art import _episode_number, _upgrade_metahub_url

    season = video.get("season")
    number = _episode_number(video)
    title = video.get("name") or video.get("title") or f"Episode {number}"
    # Only when autoplaying, so ordinary rows keep the known URL.
    extra = {"autoplay": "1"} if autoplay else {}
    return build_url("check_resume", **extra, **episode_params(
        video, meta, series_id, catalog_type, season_poster, episode_id))


def episode_params(video, meta, series_id, catalog_type="series",
                   season_poster="", episode_id=None):
    """What every route needs to act on one episode — play it or keep it."""
    from .art import _episode_number, _upgrade_metahub_url

    number = _episode_number(video)
    title = video.get("name") or video.get("title") or f"Episode {number}"
    return {
        "catalog_type": catalog_type,
        "video_id": episode_id or video.get("id"),
        "thumb": _upgrade_metahub_url(video.get("thumbnail")) or "",
        "logo": meta.get("logo") or "",
        "parent_id": series_id,
        "series_name": meta.get("name") or "",
        "episode_title": title,
        "season": video.get("season"),
        "episode": number,
        "season_poster": season_poster,
        "episode_plot": video.get("overview") or meta.get("description") or "",
    }


def countable_episode_ids(meta: dict):
    """Episode ids that count toward totals — specials excluded when hidden."""
    keep_specials = get_setting("show_specials") != "false"
    return [
        v["id"] for v in meta.get("videos", ())
        if v.get("id") and (keep_specials or v.get("season") != 0)
    ]


def listed_seasons(meta: dict):
    """The seasons a series shows, in order, with specials last or hidden."""
    seasons = sorted({
        season for v in meta.get("videos", ())
        for season in [v.get("season")]
        if season is not None
    })
    if get_setting("show_specials") == "false":
        return [s for s in seasons if s != 0]
    if 0 in seasons:
        # Specials sit after the numbered seasons, not in front of them.
        return [s for s in seasons if s != 0] + [0]
    return seasons


def season_overviews(meta: dict):
    """Each season's own description, for the seasons the feed writes one for."""
    # Some series carry the key with nothing in it, others leave it out.
    return {
        int(s["season"]): (s.get("overview") or "").strip()
        for s in meta.get("seasons") or ()
        if str(s.get("season")).lstrip("-").isdigit()
        and (s.get("overview") or "").strip()
    }


_SEASON_LABELS = {"0": "number", "1": "arc", "2": "both"}


def season_names(meta: dict):
    """Each season's arc name, for the seasons the feed names."""
    return {
        int(s["season"]): (s.get("name") or "").strip()
        for s in meta.get("seasons") or ()
        if str(s.get("season")).lstrip("-").isdigit()
        and (s.get("name") or "").strip()
    }


def season_labeller(meta: dict):
    """Names seasons the way the viewer asked, read once for the whole list."""
    names = season_names(meta or {})
    mode = _SEASON_LABELS.get(get_setting("season_labels"), "number")

    def label(season):
        plain = "Specials" if int(season) == 0 else f"Season {season}"
        arc = names.get(int(season), "")
        # An unnamed season, or one the feed calls what we already call it.
        if mode == "number" or not arc or arc == plain:
            return plain
        return arc if mode == "arc" else f"{plain} · {arc}"

    return label


def _catalog_url(catalog_type: str, catalog_id: str, extra: str):
    _, provider_base_url = _provider_context()
    return _compose_url(
        provider_base_url,
        f"catalog/{_provider_path(catalog_type)}/{_provider_path(catalog_id)}/{extra}.json",
    )


def _catalog_specs(manifest: dict, catalog_type: str):
    # "anime" is treated as "series" to use the proven pipeline.
    match_types = {catalog_type, "anime"} if catalog_type == "series" else {catalog_type}
    specs = []
    for catalog in manifest.get("catalogs", ()):
        if catalog["type"] not in match_types:
            continue

        catalog_id = catalog.get("id")
        if not catalog_id:
            continue

        catalog_name = catalog.get("name") or catalog_id
        if (
            catalog_type == "series"
            and catalog_name.strip().lower() in SERIES_CATALOG_EXCLUDED_NAMES
        ):
            continue

        has_search = any(e.get("name") == "search" for e in catalog.get("extra", ()))
        specs.append({"id": catalog_id, "name": catalog_name, "has_search": has_search})
    return specs


def series_order():
    """Where each series sits in the catalog Browse lists, by id."""
    try:
        manifest_url, _ = _provider_context()
        manifest = _cache.get(manifest_url)
        specs = _catalog_specs(manifest, "series") if manifest else None
        if not specs:
            log("[catalog] no manifest cached, so the series order waits for a browse")
            return {}
        response = _cache.get(_catalog_url("series", specs[0]["id"], "skip=0"))
        if response is None:
            log("[catalog] no catalog cached, so the series order waits for a browse")
            return {}
        return {v["id"]: n for n, v in enumerate(response.get("metas", ()))}
    except Exception as exc:
        log(f"[catalog] could not read the series order: {exc}")
        return {}


def _catalog_priority(name: str):
    return _CATALOG_PRIORITY_MAP.get(name.strip().lower(), 100)


def _parse_release_year(release_info):
    if not release_info:
        return None
    match = _YEAR_RE.search(str(release_info))
    return int(match.group()) if match else None


def _parse_air_date(video):
    """Episode air date as YYYY-MM-DD, which is what Kodi's info tags expect."""
    for field in ("firstAired", "released"):
        match = _AIR_DATE_RE.match(str(video.get(field) or ""))
        if match:
            return match.group(1)
    return None


def _parse_runtime_seconds(video):
    """Episode runtime in seconds. The feed carries minutes as a string."""
    try:
        minutes = int(str(video.get("runtime") or "").strip())
    except ValueError:
        return None
    return minutes * 60 if minutes > 0 else None
