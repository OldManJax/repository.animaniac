import os
import re
import sys

import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import xbmcvfs

import requests
import six

from six.moves.urllib.parse import parse_qs, quote_plus, urlparse, parse_qsl
from bs4 import BeautifulSoup

translatePath = xbmc.translatePath if six.PY2 else xbmcvfs.translatePath
dialog = xbmcgui.Dialog()

ADDON_ID = 'plugin.video.fanimef'
SELFADDON = xbmcaddon.Addon(id=ADDON_ID)
ADDON_TITLE = 'FANime F'
ADDON_FANART = translatePath(os.path.join('special://home/addons/' + ADDON_ID, 'fanart.jpg'))
ADDON_ICON = translatePath(os.path.join('special://home/addons/' + ADDON_ID, 'icon.png'))
ADDON_DESC = 'FANime F'

KODI_VERSION = float(xbmcaddon.Addon('xbmc.addon').getAddonInfo('version')[:4])

BASE_URL = 'https://www11.gogoanime.me'
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'

def get_headers():

    """ Gets headers to send with request """

    headers = {
        "Connection": "keep-alive",
        "Cache-Control": "max-age=0",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "en-US,en;q=0.9,fr;q=0.8",
        "Sec-Ch-Ua" : "Microsoft Edge;v=131, Chromium;v=131, Not_A Brand;v=24",
        "Referer" : BASE_URL + '/'
    }
    return headers

def item_set_info( line_item, properties ):

    """
    line item set info
    Fix listitem deprecated warnings
    """

    if KODI_VERSION > 19.8:
        vidtag = line_item.getVideoInfoTag()
        if properties.get( 'title' ):
            vidtag.setTitle( properties.get( 'title' ) )
        if properties.get( 'plot' ):
            vidtag.setPlot( properties.get( 'plot' ) )
        if properties.get( 'tvshowtitle' ):
            vidtag.setTvShowTitle( properties.get( 'tvshowtitle' ) )
        if properties.get( 'season' ):
            vidtag.setSeason( properties.get( 'season' ) )
        if properties.get( 'episode' ):
            vidtag.setEpisode( properties.get( 'episode' ) )
        if properties.get('mediatype'):
            vidtag.setMediaType(properties.get('mediatype'))
    else:
        line_item.setInfo('video', properties)

def menu_get():

    """ Create opening menu """

    addDir( 'Recent Releases', BASE_URL, 2, ADDON_ICON, ADDON_FANART, ADDON_DESC )
    addDir( 'A to Z', BASE_URL + '/anime-list.html', 3, ADDON_ICON, ADDON_FANART, ADDON_DESC )
    addDir( 'Genres', BASE_URL + '/home', 5, ADDON_ICON, ADDON_FANART, ADDON_DESC )
    addDir( 'New Seasons', BASE_URL + '/new-season.html?page=1', 6, ADDON_ICON, ADDON_FANART, ADDON_DESC )
    addDir( 'Ongoing Series', BASE_URL + '/api/ongoing_series', 11, ADDON_ICON, ADDON_FANART, ADDON_DESC )
    addDir( 'Recently Added Series', BASE_URL + '/api/recently_added_series', 11, ADDON_ICON, ADDON_FANART, ADDON_DESC )
    addDir( 'Movies', BASE_URL + '/anime-movies.html?aph=&page=1', 6, ADDON_ICON, ADDON_FANART, ADDON_DESC )
    addDir( 'Popular', BASE_URL + '/popular.html?page=1', 6, ADDON_ICON, ADDON_FANART, ADDON_DESC )
    addDir( '[COLOR snow][B]Search[/B][/COLOR]', 'url', 9, ADDON_ICON, ADDON_FANART, ADDON_DESC )

def search():

    string =''
    search_url = BASE_URL + ('/search.html?keyword=%s')
    keyboard = xbmc.Keyboard(string, 'What Would You Like To Search For?')
    keyboard.doModal()
    if keyboard.isConfirmed():
        string = keyboard.getText()
        if len(string)>1:
            string = string.replace(' ','-')
            search = search_url %string
            MainContent(search)
        else:
            dialog.notification(ADDON_TITLE, '[COLOR gold]No Term Entered[/COLOR]', ADDON_ICON, 2500)
    else:
        dialog.notification(ADDON_TITLE, '[COLOR gold]Search Cancelled[/COLOR]', ADDON_ICON, 2500)

def api_content_get(url):

    link = requests.get(url,headers=get_headers()).json()
    if link:
        for data in link:
            title = data.get( 'n', '' )
            url2 = BASE_URL + '/category/' + data.get( 'p', '' )
            addDir( title, url2, 10, ADDON_ICON, ADDON_FANART, description='' )

def recent(url):

    link = requests.get(url,headers=get_headers()).text
    soup = BeautifulSoup(link,'html.parser')
    data = soup.find('div', class_={'last_episodes'})

    for i in data.find_all('li'):
        title = i.a['title']
        title = title.encode("utf8") if six.PY2 else title
        url2 = i.a['href']
        url2 = BASE_URL + url2 if url2.startswith('/') else url2
        icon = i.find('img')
        icon = str(icon['src'])
        icon = BASE_URL + icon if icon.startswith('/') else icon
        epi = i.find('p', class_={'episode'}).text
        epi = epi.encode("utf8") if six.PY2 else epi
        addLink( '%s | %s' % (title,epi), url2, 20, icon, ADDON_FANART, description='' )

def ATOZ(url):

    link = requests.get(url,headers=get_headers()).text
    soup = BeautifulSoup(link,'html.parser')
    data = soup.find_all('li', class_={'first-char'})

    for i in data:
        title = i.a.text
        url2 = i.a['href']
        url2 = BASE_URL + url2 if url2.startswith('/') else url2
        addDir( '%s' % title, url2, 4, ADDON_ICON, ADDON_FANART, ADDON_DESC )

def ATOZ_content(url):

    if not '?page=' in url:
        url = '%s?page=1' %url
    link = requests.get(url,headers=get_headers()).text
    soup = BeautifulSoup(link,'html.parser')
    data = soup.find('ul', class_={'listing'})

    for i in data:
        try:
            title = i.a['title']
            if title =='':
                title = i.a.text
            title = title.encode("utf8") if six.PY2 else title
            url2 = i.a['href']
            url2 = BASE_URL + url2 if url2.startswith('/') else url2
            try:
                icon = re.findall(r'''img\s+src=['"](.*?)['"]''',str(i))[0]
            except Exception:
                icon = ADDON_ICON
            addDir( '%s' % title, url2, 10, icon, ADDON_FANART, ADDON_DESC )
        except Exception:
            pass

    try:
        page_get = url.split('page=')[1]
        page_base = url.split('?page=')[0]
        next_gen = int(page_get) + 1
        page_next = '%spage=%s' %( page_base, next_gen )
        addDir( '[COLOR gold][B]Next Page -->[/B][/COLOR]', page_next, 4, ADDON_ICON, ADDON_FANART, 'Next Page' )
    except Exception:
        pass

def episodes_get( url, iconimage ):
    link = requests.get(url,headers=get_headers()).text
    soup = BeautifulSoup(link,'html.parser')
    try:
        title = soup.find('div', class_={'anime_info_body_bg'}).find('h2').text
    except Exception:
        title = ''
    data = soup.find('ul', id={'episode_page'})

    for i in data.find_all('li'):
        try:
            ep_start = int( i.a['ep_start'] ) + 1
            ep_end = int( i.a['ep_end'] )
            if ep_end == 1:
                x = 1
                addLink( '%s | %s' % (title, str( x ) ), url.replace( 'category/', '' ) + '-episode-' + str( x ), 20, iconimage, ADDON_FANART, description='' )
            else:
                for x in range( ep_start, ep_end ):
                    addLink( '%s | %s' % (title, str( x ) ), url.replace( 'category/', '' ) + '-episode-' + str( x ), 20, iconimage, ADDON_FANART, description='' )
        except Exception:
            pass

def genre(url):

    link = requests.get(url,headers=get_headers()).text
    soup = BeautifulSoup(link,'html.parser')
    data = soup.find('li', class_={'movie genre hide'})
    if data:
        for i in data.find_all('a'):
            try:
                title = i['title']
                title = title.encode("utf8") if six.PY2 else title
                url2 = i['href']
                url2 = BASE_URL + url2 if url2.startswith('/') else url2
                addDir('%s' % title, url2+'?page=1', 6, ADDON_ICON, ADDON_FANART, ADDON_DESC )
            except Exception:
                pass

def MainContent(url):

    link = requests.get(url,headers=get_headers()).text
    soup = BeautifulSoup(link,'html.parser')
    data = soup.find('ul', class_={'items'})
    for i in data.find_all('li'):
        title = i.a['title']
        title = title.encode("utf8") if six.PY2 else title
        url2 = i.a['href']
        url2 = BASE_URL + url2 if url2.startswith('/') else url2
        icon = i.img['src']

        if not BASE_URL in icon:
            icon = BASE_URL + icon

        addDir('%s' % title,url2,10,icon,ADDON_FANART,description='')

    try:
        page_get = url.split('page=')[-1]
        page_base = url.rsplit('page=', 1)[0]
        next_gen = int(page_get) + 1
        page_next = '%spage=%s' %( page_base, next_gen )
        addDir('[COLOR gold][B]Next Page -->[/B][/COLOR]',page_next,6,ADDON_ICON,ADDON_FANART,'Next Page')
    except Exception:
        pass

    if 'search.html' in url and title == '':
        title = 'Sorry No Items Found'
        addLink('%s' % title,'url2',9999,ADDON_ICON,ADDON_FANART,description='')

def OnGoing(url):

    link = requests.get(url,headers=get_headers()).text
    soup = BeautifulSoup(link,'html.parser')
    data = soup.find("div", class_={'overview'})
    for i in data.find_all('li'):
        title = i.a['title']
        title = title.encode("utf8") if six.PY2 else title
        url2 = i.a['href']
        url2 = BASE_URL + url2 if url2.startswith('/') else url2
        addDir('%s' % title,url2,20,ADDON_ICON,ADDON_FANART,description='')

def recently_added(url):

    link = requests.get(url,headers=get_headers()).text
    soup = BeautifulSoup(link,'html.parser')
    data = soup.find("div", class_={'added_series_body final'})
    for i in data.find_all('li'):
        title = i.a['title']
        title = title.encode("utf8") if six.PY2 else title
        url2 = i.a['href']
        url2 = BASE_URL + url2 if url2.startswith('/') else url2
        addDir('%s' % title,url2,20,ADDON_ICON,ADDON_FANART,description='')

def LinkGetter(name, url, iconimage, description):

    link = requests.get( url.replace( BASE_URL, BASE_URL + '/embed' ), allow_redirects=False, headers=get_headers() )
    # we want the reponse url
    source_link = link.headers.get( 'Location', False )
    if source_link:
        source_link = source_link.replace( '#', '', 1 )
        if '#' in source_link:
            source_link = source_link.split( '#', 1 )
            source_link = source_link[0] + '.json?cat=' + source_link[1]
        else:
            source_link = source_link + '.json'
        xbmc.log( source_link, xbmc.LOGWARNING )
        source_json = requests.get( source_link, verify=False, headers=get_headers() ).json()
        source_link = source_json.get( 'data', {} ).get( 'sources', {} )[0].get( 'url', False )
        if source_link:

            list_item = xbmcgui.ListItem(name)

            source_tracks = source_json.get( 'data', {} ).get( 'tracks', False )
            subtitles = []
            if source_tracks:
                for track in source_tracks:
                    if track.get( 'file', False ) and track.get( 'kind', '' ) == 'captions':
                        if track.get( 'default', False ):
                            subtitles.insert( 0, track[ 'file' ] )
                        else:
                            subtitles.append( track[ 'file' ] )

            if subtitles:
                list_item.setSubtitles( subtitles )

            if 'm3u8' in source_link:

                list_item.setContentLookup(False)
                list_item.setMimeType('application/x-mpegURL')
                if KODI_VERSION < 19:
                    list_item.setProperty('inputstreamaddon', 'inputstream.adaptive')
                else:
                    list_item.setProperty('inputstream', 'inputstream.adaptive')

                list_item.setProperty('inputstream.adaptive.stream_headers', '&'.join(key+'='+quote_plus(val) for key, val in get_headers().items()))
                list_item.setProperty('inputstream.adaptive.stream_params', '&'.join(key+'='+quote_plus(val) for key, val in get_headers().items()))
                list_item.setProperty('inputstream.adaptive.manifest_headers', '&'.join(key+'='+quote_plus(val) for key, val in get_headers().items()))

                if KODI_VERSION < 22:
                    list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
                list_item.setProperty('inputstream.adaptive.original_audio_language', 'en')
                list_item.setProperty('inputstream.adaptive.stream_selection_type', 'adaptive')

            list_item.setPath(source_link)
            list_item.setArt({'icon': iconimage, 'thumb': iconimage, 'poster': iconimage})
            item_set_info( list_item, {'title': name, 'plot': description} )
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, list_item)
            quit()

def addDir( name, url, mode, iconimage, fanart, description='' ):
    u = "%s?url=%s&mode=%s&name=%s&iconimage=%s&fanart=%s&description=%s" % (sys.argv[0], quote_plus(url), mode, quote_plus(name), quote_plus(iconimage), quote_plus(fanart), quote_plus(description))
    ok=True
    list_item=xbmcgui.ListItem(name)
    list_item.setArt({'icon': iconimage, 'thumb': iconimage, 'poster': iconimage})
    item_set_info( list_item, {'title': name, 'plot': description} )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=list_item,isFolder=True)
    return ok

def addLink( name, url, mode, iconimage, fanart, description='' ):
    u = "%s?url=%s&mode=%s&name=%s&iconimage=%s&fanart=%s&description=%s" % (sys.argv[0], quote_plus(url), mode, quote_plus(name), quote_plus(iconimage), quote_plus(fanart), quote_plus(description))
    ok=True
    liz=xbmcgui.ListItem(name)
    liz.setArt({"thumb": iconimage})
    liz.setInfo('video', {'Plot': description})
    liz.setProperty('IsPlayable', 'true')
    StartParty="%s?url=%s&mode=%s&name=%s&iconimage=%s&fanart=%s&description=%s" % (sys.argv[0], quote_plus(url), '3000', quote_plus(name), quote_plus(iconimage), quote_plus(fanart), quote_plus(description))
    liz.addContextMenuItems([('[COLOR yellow][B]Start A Watch Party For %s[/B][/COLOR]' %name, 'xbmc.RunPlugin('+StartParty+')')])
    view=xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

params = dict(parse_qsl(sys.argv[2].replace("?", "")))
site = params.get("site", "0")
url = params.get("url", "0")
name = params.get("name", "0")
mode = int(params.get("mode", "0"))
iconimage = params.get("iconimage", "0")
fanart = params.get("fanart", "0")
description = params.get("description", "0")

if mode==0 or url=="0" or len(url)<1:
    menu_get()
elif mode==2:
    recent(url)
elif mode==3:
    ATOZ(url)
elif mode==4:
    ATOZ_content(url)
elif mode==5:
    genre(url)
elif mode==6:
    MainContent(url)
elif mode==7:
    OnGoing(url)
elif mode==8:
    recently_added(url)
elif mode==9:
    search()
elif mode==10:
    episodes_get(url, iconimage)
elif mode==11:
    api_content_get(url)
elif mode==20:
    LinkGetter(name, url, iconimage, description)

if mode is None or url is None or len(url)<1:
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=False)
else:
    xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
